import web
import sqlite3

render = web.template.render('views/turnos_riego', base='layout')


class ListaTurno:

    def consultarTurno(self):
        conexion = None
        try:
            conexion = sqlite3.connect("sql/metzit.db")
            conexion.row_factory = sqlite3.Row
            cursor = conexion.cursor()
            query = "SELECT * FROM turnos_riego;"
            cursor.execute(query)
            resultado = cursor.fetchall()

            datos = []
            for fila in resultado:
                item = {
                    "id_turno": fila[0],
                    "fecha": fila[1],
                    "hora_inicio": fila[2],
                    "hora_fin": fila[3],
                    "id_area": fila[4],
                    "estado": fila[5],
                }
                datos.append(item)
            return datos
        except sqlite3.Error as error:
            print(f"ERROR ListaTurno 400: {error.args}")
            return []
        except Exception as error:
            print(f"ERROR ListaTurno 401: {error.args}")
            return []
        finally:
            if conexion:
                conexion.close()

    def GET(self):
        try:
            datos = self.consultarTurno()
            return render.lista_turnos_riego(datos)
        except Exception as error:
            print(f"ERROR ListaTurno 402: {error.args}")
            return "UPS, algo fallo"
